Date Invitation V4 - Cloudflare Worker project

IMPORTANT: Upload your static files alone does NOT deploy the notification endpoint.
This is a Worker project requiring deployment via Wrangler or Git integration.

Steps (computer or GitHub workflow):
1. Extract this ZIP into a repository.
2. Install Node.js and run: npx wrangler login
3. Deploy from project directory: npx wrangler deploy
4. Cloudflare Dashboard > Workers & Pages > date-invitation-v4 > Settings > Variables and Secrets:
   add NTFY_TOPIC as Secret, with the exact private ntfy topic name (not URL).
5. Test the application and verify ntfy notification on iPhone.

The previous Worker stays unchanged. The new link will be https://date-invitation-v4.tzikas-petr.workers.dev if the name is available.

Notes: ntfy.sh topic names are not authenticated; anyone who knows/guesses a topic can publish/subscribe. Use a long random topic. The public confirmation endpoint has no CAPTCHA/rate limiting; add Cloudflare Turnstile and rate limits before broad distribution. Calendar integration is not included. Do not place NTFY_TOPIC in client-side HTML.
