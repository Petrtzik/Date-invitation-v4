export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/confirm') {
      if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
      if (!env.NTFY_TOPIC) return new Response('Notification topic not configured', { status: 503 });
      let data;
      try { data = await request.json(); } catch { return new Response('Invalid JSON', { status: 400 }); }
      const choices = ['Dinner 🍝', 'Coffee ☕', 'Drinks 🍸', 'Surprise me ✨'];
      const { activity, date, time } = data ?? {};
      if (!choices.includes(activity) || !/^\d{4}-\d{2}-\d{2}$/.test(date ?? '') || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time ?? '')) return new Response('Invalid selection', { status: 400 });
      const topic = env.NTFY_TOPIC;
      if (!/^[a-zA-Z0-9_-]{5,128}$/.test(topic)) return new Response('Invalid topic configuration', { status: 503 });
      const response = await fetch(`https://ntfy.sh/${encodeURIComponent(topic)}`, {
        method: 'POST',
        headers: { 'Title': 'New date invitation response', 'Tags': 'heart', 'Content-Type': 'text/plain; charset=utf-8' },
        body: `Date confirmed!\nActivity: ${activity}\nDate: ${date}\nTime: ${time}`,
      });
      if (!response.ok) return new Response('Notification delivery failed', { status: 502 });
      return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
    }
    return env.ASSETS.fetch(request);
  },
};
